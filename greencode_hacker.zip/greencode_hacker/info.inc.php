<?php
/* Theme information */
$theme_name = 'GreenCode_Hacker </>';
$theme_full_version = '2.0';
?>
